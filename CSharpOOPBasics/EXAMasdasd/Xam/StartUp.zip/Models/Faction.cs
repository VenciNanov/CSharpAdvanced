﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam.Models
{
    public enum Faction
    {
        CSharp,
        Java
    }
}

﻿using Exam.Models;
using Exam.Models.Characters;
using System;
using System.Collections.Generic;
using System.Text;

namespace Xam.Factories
{
    public static class CharacterFactory
    {
        public static Character CreateCharacter(string faction, string type, string name)
        {

            if (faction == "CSharp")
            {
                switch (type)
                {
                    case "Warrior":
                        return new Warrior(name, Faction.CSharp);

                    case "Cleric":
                        return new Cleric(name, Faction.CSharp);
                    default:
                        throw new ArgumentException($"Invalid character type {type}!"); ;
                }
            }
            else if (faction == "Java")
            {
                switch (type)
                {
                    case "Warrior":
                        return new Warrior(name, Faction.Java);

                    case "Cleric":
                        return new Cleric(name, Faction.Java);
                    default:
                        throw new ArgumentException($"Invalid character type {type}!");
                }
            }
            else
            {
                throw new ArgumentException($"Invalid faction {faction}!");
            }
        }
    }
}

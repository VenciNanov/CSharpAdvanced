﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam.Models.Bags
{
    public class Backpack : Bag
    {
        public Backpack() : base(20)
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam.Models.Bags
{
    public class Satchel : Bag
    {
        public Satchel() : base(20)
        {
        }
    }
}

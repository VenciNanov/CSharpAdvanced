﻿public interface IAddable
{
    void Add(string element);
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class PerformanceCar : Car
{
    private List<string> addOns;

    public PerformanceCar(string brand, string model, int yearOfProduction, int horsepower, int acceleration, int suspension, int durability) : base(brand, model, yearOfProduction, horsepower, acceleration, suspension, durability)
    {
        addOns = new List<string>();
        this.Horsepower += horsepower / 2;
        this.Suspension -= (suspension / 4);
    }

    public List<string> AddOns
    {
        get { return addOns; }
    }

    public override string ToString()
    {
        var sb = base.ToString();

        if (this.AddOns.Any())
        {
           
          sb+= $"Add-ons: {string.Join(", ", this.AddOns)}";
        }
        else
        {
            sb += $"Add-ons: None";
        }

        return sb.ToString();
    }

}

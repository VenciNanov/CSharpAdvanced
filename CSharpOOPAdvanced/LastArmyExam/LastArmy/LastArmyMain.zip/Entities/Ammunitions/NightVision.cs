﻿  public class NightVision: Ammunition
    {
        public const double WeightPoints = 0.8;

        public NightVision(string name)
            : base (name, WeightPoints)
        {
        }
    }

﻿public class AutomaticMachine : Ammunition
{
    public const double WeightPoints = 6.3;

    public AutomaticMachine(string name)
        : base(name, WeightPoints)
    {
    }
}
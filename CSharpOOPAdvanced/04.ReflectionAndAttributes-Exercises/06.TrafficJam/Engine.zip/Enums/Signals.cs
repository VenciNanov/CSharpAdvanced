﻿using System;
using System.Collections.Generic;
using System.Text;

public enum Signals
{
    Red,
    Green,
    Yellow
}

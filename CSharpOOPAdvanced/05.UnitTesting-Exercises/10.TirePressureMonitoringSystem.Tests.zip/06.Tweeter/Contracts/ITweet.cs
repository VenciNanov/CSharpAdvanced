﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ITweet
{
    string Message { get; set; }
}
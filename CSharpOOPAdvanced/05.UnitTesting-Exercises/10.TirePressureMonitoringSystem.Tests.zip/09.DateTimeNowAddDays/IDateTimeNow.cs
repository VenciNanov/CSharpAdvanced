﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IDateTimeNow
{
    DateTime Now { get; set; }
}

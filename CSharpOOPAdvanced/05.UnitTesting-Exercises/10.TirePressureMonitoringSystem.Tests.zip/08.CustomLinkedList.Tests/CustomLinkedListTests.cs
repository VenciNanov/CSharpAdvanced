﻿using System;

namespace _08.CustomLinkedList.Tests
{
    public class Class1
    {
    }
}

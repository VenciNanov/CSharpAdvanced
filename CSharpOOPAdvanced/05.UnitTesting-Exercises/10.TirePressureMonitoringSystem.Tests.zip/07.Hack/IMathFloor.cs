﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IMathFloor
{
    double MathFloor(double value);
}

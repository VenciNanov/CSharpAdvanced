﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IMathAbs
{
    double MathAbs(double value);
}

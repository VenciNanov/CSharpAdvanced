﻿using System;

namespace _09.DateTimeNowAddDays.Tests
{
    public class Class1
    {
    }
}

﻿using System;

namespace _10.TirePressureMonitoringSystem.Tests
{
    public class Class1
    {
    }
}

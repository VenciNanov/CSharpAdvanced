﻿public enum WorkingMode
{
    Full = 100,
    Half = 50,
    Energy = 20
}

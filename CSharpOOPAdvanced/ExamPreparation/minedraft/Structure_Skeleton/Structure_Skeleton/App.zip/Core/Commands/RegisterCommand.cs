﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class RegisterCommand : Command
{
    private IHarvesterController harvesterController;
    private IProviderController providerController;

    public RegisterCommand(IHarvesterController harvesterController,IProviderController providerController,IList<string> arguments) : base(arguments)
    {
        this.harvesterController = harvesterController;
        this.providerController = providerController;
    }

    public override string Execute()
    {
        var type = Arguments[0];
        var args = Arguments.Skip(1).ToList();

        if (type=="Harvester")
        {
            return RegisterHarvester(args);
        }
        return RegisterProvider(args);
    }

    private string RegisterProvider(List<string> args)
    {
       return this.providerController.Register(args);
    }

    private string RegisterHarvester(List<string> args)
    {
        return this.harvesterController.Register(args);
    }
}

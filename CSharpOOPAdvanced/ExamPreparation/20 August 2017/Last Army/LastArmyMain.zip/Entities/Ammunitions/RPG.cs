﻿public class RPG : Ammunition
{
    public const double WeightPoints = 17.1;

    public RPG(string name)
        : base(name, WeightPoints)
    {
    }
}